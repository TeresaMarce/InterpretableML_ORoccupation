.onUnload <- function(libpath)
    library.dynam.unload("uba", libpath)

.noGenerics <- TRUE

